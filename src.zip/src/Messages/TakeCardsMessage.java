package Messages;

public class TakeCardsMessage extends Message {
}
