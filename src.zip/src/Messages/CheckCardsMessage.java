package Messages;

public class CheckCardsMessage extends Message {
}
